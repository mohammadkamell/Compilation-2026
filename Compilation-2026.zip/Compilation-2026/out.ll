declare void @print_integer(i64)
declare i64 @read_integer()
declare void @dolphin_div_by_zero()

define i64 @dolphin_main () {
 %sc_res_3 = alloca i1
 %x_2 = alloca i64
 %temp_1 = call i64 @read_integer ()
 store i64 %temp_1, i64* %x_2
 %temp_4 = load i64, i64* %x_2
 %temp_5 = icmp ne i64 %temp_4, 0
 store i1 %temp_5, i1* %sc_res_3
 br i1 %temp_5, label %sc_rhs_6, label %sc_done_7
sc_rhs_6:
 %temp_8 = load i64, i64* %x_2
 %is_zero_9 = icmp eq i64 %temp_8, 0
 br i1 %is_zero_9, label %div_error_10, label %div_ok_11
div_error_10:
 call void @dolphin_div_by_zero ()
 unreachable
div_ok_11:
 %temp_12 = sdiv i64 10, %temp_8
 %temp_13 = icmp sgt i64 %temp_12, 1
 store i1 %temp_13, i1* %sc_res_3
 br label %sc_done_7
sc_done_7:
 %temp_14 = load i1, i1* %sc_res_3
 br i1 %temp_14, label %then_15, label %else_16
then_15:
 call void @print_integer (i64 1)
 br label %merge_17
else_16:
 call void @print_integer (i64 2)
 br label %merge_17
merge_17:
 ret i64 0
}
