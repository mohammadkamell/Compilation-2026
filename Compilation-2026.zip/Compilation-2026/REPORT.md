# Dolphin Compiler — Phase 4 Report

## Task 1: Extended Parser
We extended the Menhir grammar in `src/frontend/parser.mly` and AST definitions in `src/ir/ast.ml` to parse top-level function declarations (`<return-type> <name>(<params>) { <body> }`), optional/void return statements (`return;`), and comma expressions (`e1, e2`). Comma expressions are parsed with appropriate precedence and restricted from appearing as bare expression statements or top-level function arguments.

## Task 2: Extended Semantic Analysis
We implemented a two-pass type-checking pipeline in `src/frontend/semant.ml` to support mutual recursion across top-level functions. The first pass validates function signatures, uniqueness of function and parameter names, and ensures the presence of a parameterless `int main()` entry point, populating a global function environment; the second pass typechecks each function body and verifies that all control-flow paths in non-void functions return a value of the declared return type.

## Task 3: Code Generation for Phase 4 (My Part)
We extended the LLVM IR code generator in `src/backend/codegen.ml` to translate each Dolphin function declaration into a corresponding LLVM function definition (`@dolphin_main` for `main` and `@dolphin_fun_<name>` for user functions). Function arguments are mapped to local stack slots via `alloca` and `store` instructions so that parameters can be mutated as local variables within function bodies without affecting caller state. We also implemented codegen for `CommaExpr` by evaluating the left subexpression for side effects before evaluating and returning the right subexpression, supported both value returns and `ret void`, and terminated unclosed basic blocks safely.

## Task 4: Testing and Consolidation (My Part)
We ported all 61 existing test cases (33 positive, 28 negative) to the Phase 4 syntax by wrapping top-level statements in `int main() { ... }`, updating the test runner scripts and unit test suites accordingly. We developed 12 new comprehensive test programs in `test/tests/assignment-07-tests/` exercising Phase 4 features, including function calls, parameter mutation, mutual recursion, void functions, comma expressions in loops and assignments, and nested function invocations. All tests pass with 100% success rate across both `dune runtest` and `run_tests.sh` (83/83 integration tests).

## Reproducing the Solution

1. **Building the compiler**:
   ```bash
   dune build
   ```

2. **Running the full test suite**:
   ```bash
   bash run_tests.sh
   # Unit tests can also be run via:
   dune runtest
   ```

3. **Compiling and executing a Dolphin source file**:
   ```bash
   # Compile Dolphin source to LLVM IR
   dune exec dolphin -- compile --phase 4 <file.dlp> -o out.ll

   # Link with runtime and produce executable
   clang out.ll runtime/runtime.c -o prog

   # Execute
   ./prog
   ```

4. **Pre-submission verification**:
   ```bash
   ./presub.sh 4 <path_to_zip>
   ```